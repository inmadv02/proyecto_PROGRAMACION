package crud;

public class CrudObjetos {

}
