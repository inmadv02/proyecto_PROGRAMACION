package crud;

public class CrudObjetos {
	
	//public    crearObjeto () {
	//}
	
	//public    borrarObjeto () {
	//}

}
