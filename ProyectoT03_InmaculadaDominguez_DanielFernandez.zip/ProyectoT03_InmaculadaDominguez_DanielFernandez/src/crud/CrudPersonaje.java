package crud;

public class CrudPersonaje {

}
