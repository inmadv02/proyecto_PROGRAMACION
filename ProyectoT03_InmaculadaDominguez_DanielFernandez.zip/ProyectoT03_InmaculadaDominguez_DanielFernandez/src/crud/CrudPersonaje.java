package crud;

public class CrudPersonaje {
	
	//public modificarVida (){
	
	//public modificarFuerza (){

}
