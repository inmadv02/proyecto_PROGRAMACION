package model;

public class Mochila {
	
	private Objetos [] objetos;

	public Mochila(Objetos[] objetos) {
		super();
		this.objetos = objetos;
	}

	public Objetos[] getO() {
		return objetos;
	}

	public void setO(Objetos[] o) {
		this.objetos = o;
	}
	
	

}
