package model;

public class Mochila {
	
	private Objetos [] o;

	public Objetos[] getO() {
		return o;
	}

	public void setO(Objetos[] o) {
		this.o = o;
	}
	

}
