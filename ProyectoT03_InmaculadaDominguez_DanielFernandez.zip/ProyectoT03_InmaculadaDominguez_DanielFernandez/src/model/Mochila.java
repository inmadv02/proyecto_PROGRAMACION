package model;

public class Mochila {

}
