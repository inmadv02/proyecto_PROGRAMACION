package model;

public class Objetos {

}
