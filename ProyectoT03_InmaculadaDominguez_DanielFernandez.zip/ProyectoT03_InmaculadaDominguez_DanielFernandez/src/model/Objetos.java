package model;

public class Objetos {
	
	private String nombre;
	private double BonusVida;
	private double BonusFuerza;
	//private double BonusEnergía;
	
	
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public double getBonusVida() {
		return BonusVida;
	}
	public void setBonusVida(double bonusVida) {
		BonusVida = bonusVida;
	}
	public double getBonusFuerza() {
		return BonusFuerza;
	}
	public void setBonusFuerza(double bonusFuerza) {
		BonusFuerza = bonusFuerza;
	}
	
	

}
