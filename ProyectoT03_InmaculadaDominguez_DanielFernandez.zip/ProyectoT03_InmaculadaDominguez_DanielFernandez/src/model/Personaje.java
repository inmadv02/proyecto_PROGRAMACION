package model;

public class Personaje {

}
