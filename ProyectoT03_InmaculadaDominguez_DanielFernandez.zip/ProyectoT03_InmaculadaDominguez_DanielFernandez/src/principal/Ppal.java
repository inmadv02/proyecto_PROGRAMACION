package principal;

import vistas.Mapa;

public class Ppal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Mapa.imprimirMapa();

	}

}
