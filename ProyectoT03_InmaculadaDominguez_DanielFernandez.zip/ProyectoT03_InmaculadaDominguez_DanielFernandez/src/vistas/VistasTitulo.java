package vistas;

public class VistasTitulo {
	
	public static void imprimirTitulo () {
		
		System.out.println("\r\n"
				+ "\t  ________                                    __  .__               \r\n"
				+ "\t  \\_____  \\  __ _______ ____________    _____/  |_|__| ____   ____  \r\n"
				+ "\t   /  / \\  \\|  |  \\__  \\\\_  __ \\__  \\  /    \\   __\\  |/    \\_/ __ \\ \r\n"
				+ "\t  /   \\_/   \\  |  // __ \\|  | \\// __ \\|   |  \\  | |  |   |  \\  ___/ \r\n"
				+ "\t  \\_____\\ \\_/____/(____  /__|  (____  /___|  /__| |__|___|  /\\___  >\r\n"
				+ "\t         \\__>          \\/           \\/     \\/             \\/     \\/ \r\n"
				+ "");
		
	   System.out.println();
	   System.out.println();
	}

}
