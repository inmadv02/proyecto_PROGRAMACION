package vistas;

public class Historia {

}
