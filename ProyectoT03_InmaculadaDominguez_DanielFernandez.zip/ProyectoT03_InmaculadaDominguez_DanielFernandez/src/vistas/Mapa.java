package vistas;

public class Mapa {

}
