package vistas;

public class Mapa {
	
	public static void imprimirMapa () {
		
		
		//Primer intento
		for(int i = 0; i < 10; i++) {
			System.out.print("* ");
		}
		System.out.println();
		
		for(int i = 0; i < 8; i++) {
			System.out.print("* ");
			for(int j = 0; j < 16; j++) {
				System.out.print(" ");
				
//				if(i == 1 && j == 1) {
//					System.out.print("*");
//				}
//				
//				if(i == 2 && j == 1) {
//					System.out.print("*");
//				}
//				
//				if(i == 3 && j == 1) {
//				System.out.print("*");
//				
//				}
			
			}
			System.out.println("*");
			
			if(i == 2) {
				System.out.print("*  ");
			}
		}
		
	
		for(int i = 0; i < 10; i++) {
			System.out.print("* ");
		}
		
		//Segundo intento
		
//		for (int i = 0; i < 10; i++) {
//			for (int j = 0; j < 10; j++) {
//				System.out.print("* ");
//				
//				if(i != 9 && i != 0 && j == 2) {
//					System.out.print(" ");
//				}
//				
//				if(j == 1 && i == 1) {
//					System.out.print(" ");
//				}
//				
//			}System.out.println(" ");
//		}
//		
//		
//		System.out.println("**********************");
//		for (int i = 0; i < 9 ; i++) {
//			for (int j = 0; j < 8; j++) {
//				System.out.print("*  ");
//				
//				if( i == 1 && j == 0 && j == 8 ) {
//					System.out.print("   ");
//					
//				}
//		
//			}
//			System.out.println();
//			
//			
//		}
//		
//		
  }

}
