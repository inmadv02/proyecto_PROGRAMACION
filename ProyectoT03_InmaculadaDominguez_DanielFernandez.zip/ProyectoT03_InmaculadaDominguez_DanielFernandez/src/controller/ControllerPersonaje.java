package controller;

public class ControllerPersonaje {

}
